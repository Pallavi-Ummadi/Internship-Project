# forms.py
from django import forms
from .models import booking

class BookingForm(forms.ModelForm):
    class Meta:
        model = booking
        fields = ['check_in_date', 'check_out_date', 'guest_name', 'guest_email']
