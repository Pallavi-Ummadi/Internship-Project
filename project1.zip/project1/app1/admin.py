from django.contrib import admin
from .models import travel,booking

admin.site.register(travel)
admin.site.register(booking)
