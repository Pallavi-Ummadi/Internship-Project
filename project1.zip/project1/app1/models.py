from django.db import models

class travel(models.Model):
    name = models.CharField(max_length=100,default=None)
    state1=models.CharField(max_length=100,default=None)
    train_cost1=models.IntegerField(default=None)
    car_cost1=models.IntegerField(default=None)
    bus_cost1=models.IntegerField(default=None)
    flight_cost1=models.IntegerField(default=None)
    image = models.ImageField(upload_to="pics/",default=None)
    description=models.TextField(default=None)
    hotel_image=models.ImageField(upload_to="pics/",default=None)
    hotel_name=models.CharField(max_length=100,default=None)
    hotel_cost=models.IntegerField(default=None)
    hotel_description=models.TextField(default=None,max_length=1000)
    hotel_image1=models.ImageField(upload_to="pics/",default=None)
    hotel_name1=models.CharField(max_length=100,default=None)
    hotel_cost1=models.IntegerField(default=None)
    hotel_description1=models.TextField(default=None,max_length=1000)
    hotel_image2=models.ImageField(upload_to="pics/",default=None)
    hotel_name2=models.CharField(max_length=100,default=None)
    hotel_cost2=models.IntegerField(default=None)
    hotel_description2=models.TextField(default=None,max_length=1000)
    famous_food=models.CharField(max_length=100,default=None)
    food_cost=models.IntegerField(default=None)
    food_location=models.CharField(max_length=1000,default=None)
    food_image=models.ImageField(upload_to="pics/",default=None)



class booking(models.Model):
    location=models.CharField(max_length=100,default=None)
    Hotel= models.CharField(max_length=100,default=None)
    check_in = models.DateField()
    check_out = models.DateField()
    name = models.CharField(max_length=100)
    email = models.EmailField()
    rooms=models.IntegerField(default=None)