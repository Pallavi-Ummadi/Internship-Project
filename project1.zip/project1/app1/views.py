from django.http import HttpResponse
from django.shortcuts import render,redirect ,get_object_or_404
from django.contrib.auth.models import User, auth
from django.contrib.auth import authenticate,logout
from django.contrib.auth import login
from django.contrib import messages
from .models import travel,booking
from django.contrib.auth.decorators import login_required

def register(request):
    if request.method == 'POST':
        username=request.POST['username']
        email=request.POST['email']
        pass1=request.POST['password']
        pass2=request.POST['confirmPassword']
        if pass1==pass2:
            if User.objects.filter(email=email).exists():
                messages.info(request,'Email already exits')
                return render(request,'register.html')
            elif User.objects.filter(username=username).exists():
                messages.info(request,'username  already exits')
                return render(request,'register.html')
            else:
                user=User.objects.create_user(username=username, email= email, password=pass1)
                user.save()
                messages.success(request,"Registration Successful! You can now login.")
                return render(request,'login.html')
        else:
            messages.error(request,'Password is not same')
    return render(request,'register.html')


def user_login(request):
    if request.user.is_authenticated:
        return redirect('index')
    if request.method=="POST":
        name1=request.POST.get("username")
        password=request.POST.get("password")
        user=authenticate(username=name1, password=password)
        if user is not None:
            login(request,user)
            return redirect('index')
        else:
            messages.error(request,"Enter Correct Credentials!")
            return redirect('login')
    return  render(request,'login.html')


def user_logout(request):
    logout(request)
    return render(request,'login.html')


def location(request):
    if  request.method=='POST':
        name = request.POST['name']
        state1=request.POST['state1']
        train_cost1=request.POST['train_cost1']
        car_cost1=request.POST['car_cost1']
        bus_cost1=request.POST['bus_cost1']
        flight_cost1=request.POST['flight_cost1']
        description=request.POST['description']
        hotel_cost=request.POST['hotel_cost']
        hotel_name=request.POST['hotel_name']
        hotel_description=request.POST['hotel_description']
        hotel_cost1=request.POST['hotel_cost1']
        hotel_name1=request.POST['hotel_name1']
        hotel_description1=request.POST['hotel_description1']
        hotel_cost2=request.POST['hotel_cost2']
        hotel_name2=request.POST['hotel_name2']
        hotel_description2=request.POST['hotel_description2']
        famous_food=request.POST['famous_food']
        food_cost=request.POST['food_cost']
        food_location=request.POST['food_location']
        hotel_image=request.FILES.get('hotel_image')
        hotel_image1=request.FILES.get('hotel_image1')
        hotel_image2=request.FILES.get('hotel_image2')
        food_image=request.FILES.get('food_image')
        image=request.FILES.get('image')
        location=travel(name=name,state1=state1,train_cost1=train_cost1,car_cost1=car_cost1,bus_cost1=bus_cost1,flight_cost1=flight_cost1,description=description,hotel_cost=hotel_cost,hotel_description=hotel_description,hotel_cost1=hotel_cost1,hotel_description1=hotel_description1,hotel_cost2=hotel_cost2,hotel_description2=hotel_description2,
                        famous_food=famous_food,food_cost=food_cost,food_location=food_location,hotel_image=hotel_image,hotel_image1=hotel_image1,hotel_image2=hotel_image2,food_image=food_image,image=image,hotel_name=hotel_name,hotel_name1=hotel_name1,hotel_name2=hotel_name2,
                       )
        location.save()
        return redirect('index')
    return render(request,"location.html")

def delete_location(request,id):
    location=travel.objects.filter(id=id)
    location.delete()
    return redirect("index")

def edit(request,id):
    if request.method=="POST":
        obj=travel.objects.get(id=id)
        obj.name=request.POST['name']
        obj.state1=request.POST['state1']
        obj.train_cost1=request.POST['train_cost1']
        obj.car_cost1=request.POST['car_cost1']
        obj.flight_cost1=request.POST['flight_cost1']
        obj.description=request.POST['description']
        obj.hotel_cost=request.POST['hotel_cost']
        obj.hotel_description=request.POST['hotel_description']
        obj.famous_food=request.POST['famous_food']
        obj.food_cost=request.POST['food_cost']
        obj.food_location=request.POST['food_location']
        obj.bus_cost1=request.POST['bus_cost1']
        obj.hotel_name=request.POST['hotel_name']
        obj.hotel_name1=request.POST['hotel_name1']
        obj.hotel_name2=request.POST['hotel_name2']
        obj.hotel_cost1=request.POST['hotel_cost1']
        obj.hotel_description1=request.POST['hotel_description1']
        obj.hotel_cost2=request.POST['hotel_cost2']
        obj.hotel_description2=request.POST['hotel_description2']
        obj.save()
        return redirect("index")

    location=travel.objects.get(id=id)
    return render(request,'edit.html',{'location':location})

def image_desc(request,id):
    item=get_object_or_404(travel,id=id)
    return render(request,'tours.html',{'items':[item]})


def home(request):
    return render(request,'home.html')


def index(request):
    items=travel.objects.all()
    return render(request,'index.html',{'items':items})


def about(request):
    return render(request,'about.html')

@login_required
def tours(request):
    items=travel.objects.all()
    return render(request,'tours.html')

def contact(request):
    return render(request,'contact.html')

@login_required
def book(request):
    if request.method=='POST':
        name=request.POST.get('name','')
        hotel_name=request.POST.get('hotel_name','')
        location_exists=travel.objects.filter(name__iexact=name).exists()
        hotel_exists=travel.objects.filter(name__iexact=hotel_name).exists()
        if location_exists is None:
            messages.error(request, 'Location not found.')
            return render(request, 'book.html')
        elif hotel_exists is None:
            messages.error(request, 'Hotel not found.')
            return render(request, 'book.html')
        else:
            new_booking=travel(name=name,hotel_name=hotel_name)
            new_booking.save()
            messages.success(request,'Booking successfull')
            return render(request,'book.html')
    return render(request,'book.html')


@login_required
def book_hotel(request):
    if request.method =='POST':
        location=request.POST.get('location')
        Hotel=request.POST.get('Hotel')
        name = request.POST.get('name')
        email = request.POST.get('email')
        check_in = request.POST.get('check_in')
        check_out = request.POST.get('check_out')
        rooms = request.POST.get('rooms')

        # Create a booking object
        book_hotel = booking(
            location=location,
            Hotel=Hotel,
            name=name,
            email=email,
            check_in=check_in,
            check_out=check_out,
            rooms=rooms
        )
        book_hotel.save()
        messages.success(request,'Booked Successful')
        return render(request,'book.html')
    else:
        return render(request,'book.html')
