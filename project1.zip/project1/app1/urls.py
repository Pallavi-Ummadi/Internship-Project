from django.urls import path
from app1 import views
from .views import travel
urlpatterns=[
     path('index',views.index,name='index'),
    path('about',views.about,name='about'),
    path('tours',views.tours,name='tours'),
    path('contact',views.contact,name='contact'),
    path('',views.home,name='home'),
    path('register',views.register,name='register'),
    path('login/',views.user_login,name='login'),
    path('delete/<int:id>',views.delete_location,name="delete"),
    path('edit/<int:id>',views.edit,name="edit"),
    path('location',views.location,name='location'),
    path('logout/',views.user_logout,name="logout"),
    path('tours/<int:id>/',views.image_desc,name='tours'),
    path('book',views.book_hotel,name='book'),
    path('book',views.book,name='book')
] 